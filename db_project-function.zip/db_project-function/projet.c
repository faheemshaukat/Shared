#include <stdio.h>
#include <postgres.h>
#include <float.h>
#include <math.h>
#include <stdlib.h>


#include "utils/builtins.h"
#include "libpq/pqformat.h"
#include "smallchesslib.h"

PG_MODULE_MAGIC;


typedef struct
{
     char event,
          date,
          round,
          site,
          white,
          black;
} Chessgame;

PG_FUNCTION_INFO_V1(chessgame_in);

Datum 
   
chessgame_in(PG_FUNCTION_ARGS) {
    char *str = PG_GETARG_CSTRING(0);

    if (strlen(str) != 6) {
        ereport(ERROR,
            (errcode(ERRCODE_INVALID_TEXT_REPRESENTATION),
             errmsg("input string length must be 6 characters")));
    }

    Chessgame *result = (Chessgame *) palloc(sizeof(Chessgame));
    result->event = str[0];
    result->date= str[1];
    result->round = str[2];
    result->site= str[3];
    result->white = str[4];
    result->black= str[5];

    PG_RETURN_POINTER(result);
    }

PG_FUNCTION_INFO_V1(chessgame_out);

Datum chessgame_out(PG_FUNCTION_ARGS) {
    Chessgame *val = (Chessgame *) PG_GETARG_POINTER(0);

    char *result = palloc(7); // 6 arguments + 1 pour le caractère nul
    result[0] = val->event;
    result[1] = val->date;
    result[2] = val->round;
    result[3] = val->site;
    result[4] = val->white;
    result[5] = val->black;
    result[6] = '\0';

    PG_RETURN_CSTRING(result);
}

/* fmgr macros complex type */


/*****************************************************************************/

/*static Chessgame*
chessgame_make(char event, char date, char round, char site, char white, char black, char result, char fen_notation)
{
  Chessgame *c = palloc0(sizeof(Chessgame));
  c->event = event;
  c->date = date;
  c->round = round;
  c->site = site;
  c->white= white;
  c->black = black;
  c->result = result;
  c->fen_notation = fen_notation;
  
  return c;
}*/

typedef struct
{
     string fen_notation
} Chessboard;

PG_FUNCTION_INFO_V1(chessboard_in);

Datum 
   
chessboard_in(PG_FUNCTION_ARGS) {
    char *str = PG_GETARG_CSTRING(0);


    Chessgame *result = (Chessboard *) palloc(sizeof(Chessboard));
    result->fen_notation = str[0];

    PG_RETURN_POINTER(result);
    }

PG_FUNCTION_INFO_V1(chessboard_out);

Datum chessboard_out(PG_FUNCTION_ARGS) {
    Chessboard *val = (Chessboard *) PG_GETARG_POINTER(0);

    char *result = palloc(2); // 1 arguments + 1 pour le caractère nul
    result[0] = val->fen_notation;
    result[1] = '\0';

    PG_RETURN_CSTRING(result);
}

/*********************************************************************************/
PG_FUNCTION_INFO_V1(getBoard);

Datum getBoard(PG_FUNCTION_ARGS) {
    // Extraire les arguments de la fonction
    Chessgame *chessgame = (Chessgame *) PG_GETARG_POINTER(0);
    int halfMoves = PG_GETARG_INT32(1);

    // Créer un échiquier
    Chessboard *result = (Chessboard *) palloc(sizeof(Chessboard));

    // Initialiser un échiquier avec la position initiale
    // Utilise la librairie smallchesslib.h
    SCL_Board board;
    SCL_boardInit(board);

    // Appliquer les mouvements du jeu
    for (int i = 0; i < halfMoves; i++) {
        // Utiliser SmallChessLib pour effectuer les mouvements
        uint8_t squareFrom = SCL_SQUARE(chessgame->moves[i].fromColumn - 'a', chessgame->moves[i].fromRow - 1);
        uint8_t squareTo = SCL_SQUARE(chessgame->moves[i].toColumn - 'a', chessgame->moves[i].toRow - 1);
        char promotePiece = chessgame->moves[i].promotePiece;

        SCL_MoveUndo moveUndo = SCL_boardMakeMove(board, squareFrom, squareTo, promotePiece);
    }

    // Copier la notation FEN du nouvel échiquier dans le résultat
    char fenBuffer[SCL_FEN_MAX_LENGTH];
    uint8_t fenLength = SCL_boardToFEN(board, fenBuffer);
    result->fen_notation = pstrndup(fenBuffer, fenLength);

    PG_RETURN_POINTER(result);
}

/*************************************************************************************************/

// Définition de la fonction getFirstMoves
PG_FUNCTION_INFO_V1(getFirstMoves);
Datum getFirstMoves(PG_FUNCTION_ARGS)
{
    // Extraire les arguments de la fonction
    Chessgame *chessgame = (Chessgame *)PG_GETARG_POINTER(0);
    int numMoves = PG_GETARG_INT32(1);

    // Vérifier si le nombre de mouvements demandé est valide
    if (numMoves < 0)
    {
        ereport(ERROR,
                (errcode(ERRCODE_INVALID_PARAMETER_VALUE),
                 errmsg("Le nombre de demi-coups doit être supérieur ou égal à zéro")));
    }

    // Créer une nouvelle structure Chessgame pour stocker les premiers mouvements
    Chessgame *result = (Chessgame *)palloc(sizeof(Chessgame));

    // Copier les premiers N mouvements
    for (int i = 0; i < numMoves && i < 6; i++)
    {
        result->event = chessgame->event;
        result->date = chessgame->date;
        result->round = chessgame->round;
        result->site = chessgame->site;
        result->white = chessgame->white;
        result->black = chessgame->black;
    }

    PG_RETURN_POINTER(result);
}
/*************************************************************************************************/

PG_FUNCTION_INFO_V1(hasOpening);

Datum hasOpening(PG_FUNCTION_ARGS) {
    // Extract the arguments of the function
    chessgame *game1 = (chessgame *)PG_GETARG_POINTER(0);
    chessgame *opening_moves = (chessgame *)PG_GETARG_POINTER(1);

    // Compare the opening moves
    for (int i = 0; i < strlen(opening_moves->pgn); i++) {
        if (opening_moves->pgn[i] != game1->pgn[i]) {
            PG_RETURN_BOOL(false);
        }
    }

    // If all opening moves match, return true
    PG_RETURN_BOOL(true);
}

/*************************************************************************************************/

PG_FUNCTION_INFO_V1(hasBoard);

Datum hasBoard(PG_FUNCTION_ARGS) {
    const SCL_Record *game1_san = PG_GETARG_POINTER(0);
    const char *game2_fen = PG_GETARG_CSTRING(1);
    int halfMoves = PG_GETARG_INT32(2);

    SCL_Board *board = board_value(*game1_san, halfMoves);
    char game1_fen[256];
    game1_fen[0] = '\0';
    SCL_boardToFEN(*board, game1_fen);

    bool result = (strcmp(game2_fen, game1_fen) == 0);

    PG_FREE_IF_COPY(game1_san, 0);

    PG_RETURN_BOOL(result);
}

