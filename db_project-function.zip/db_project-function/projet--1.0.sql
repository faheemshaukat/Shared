-- complain if script is sourced in psql, rather than via CREATE EXTENSION
\echo Use "CREATE EXTENSION projet" to load this file. \quit


/******************************************************************************
* Input/Output
******************************************************************************/
 

 
CREATE OR REPLACE FUNCTION chessgame_in(cstring)
  RETURNS chessgame
  LANGUAGE C IMMUTABLE STRICT AS '$libdir/projet', 'chessgame_in';
 
CREATE OR REPLACE FUNCTION chessgame_out(chessgame)
  RETURNS cstring
  LANGUAGE C IMMUTABLE STRICT AS '$libdir/projet', 'chessgame_out';

 
CREATE TYPE chessgame (
  internallength = 7,
  input          = chessgame_in,
  output         = chessgame_out,
  alignment      = char,
  storage        =plain
);

CREATE OR REPLACE FUNCTION chessboard_in(cstring)
  RETURNS chessboard
  LANGUAGE C IMMUTABLE STRICT AS '$libdir/projet', 'chessboard_in';
 
CREATE OR REPLACE FUNCTION chessboard_out(chessboard)
  RETURNS cstring
  LANGUAGE C IMMUTABLE STRICT AS '$libdir/projet', 'chessboard_out';

 
CREATE TYPE chessboard (
  internallength = 7,
  input          = chessboard_in,
  output         = chessboard_out,
  alignment      = char,
  storage        =plain
);

-- Function to get the board state
CREATE OR REPLACE FUNCTION getBoard(chessgame chessgame, half_moves INTEGER)
RETURNS chessboard
LANGUAGE C IMMUTABLE STRICT AS '$libdir/projet', 'getBoard';

CREATE OR REPLACE FUNCTION hasBoard(chessgame, chessboard, integer)
RETURNS BOOLEAN
LANGUAGE C IMMUTABLE STRICT AS '$libdir/projet', 'hasBoard';

CREATE OR REPLACE FUNCTION hasOpening(chessgame, chessgame)
RETURNS BOOLEAN
LANGUAGE C IMMUTABLE STRICT AS '$libdir/projet', 'hasOpening';
